from one.two import *
from one.two.text import show_text

if __name__ == '__main__':
    print(f'Given number: {x}\nFavorite movies: {favorite}')
    show_text('Text is displayed correctly!')
    