def show_text(text):
    print(f'Given text: {text}')
