favorite = ['Once Upon a Time in Hollywood', 'Catch me if you can', 'Good Will Hunting']
