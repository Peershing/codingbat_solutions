if __name__ == '__main__':
    try:
        with open('ex1.txt', 'r', encoding="utf-8") as file:
            content = file.read()
    except FileNotFoundError:
        print('File doesn\'t exist')
    else:
        print(f'# chars: {len(content)}')
        expression = input('Searched phrase: ')
        print(f'# occurrences: {content.count(expression)}')
