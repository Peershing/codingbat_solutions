if __name__ == '__main__':
    with open('ex1.txt', 'a', encoding='utf-8') as file:
        while line := input('Enter text: '):
            file.write(f'{line}\n')
