if __name__ == '__main__':
    while True:
        try:
            num = float(input('Enter number: '))
            print(f'The number is: {num}')
            break
        except ValueError:
            print(f'Incorrect number')
            continue
